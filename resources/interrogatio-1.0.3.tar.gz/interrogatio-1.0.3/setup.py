# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['interrogatio',
 'interrogatio.core',
 'interrogatio.handlers',
 'interrogatio.shortcuts',
 'interrogatio.themes',
 'interrogatio.validators',
 'interrogatio.widgets']

package_data = \
{'': ['*'], 'interrogatio.themes': ['theme_files/*']}

install_requires = \
['prompt-toolkit>=3.0.18,<4.0.0']

extras_require = \
{'yaml': ['PyYAML>=5.4.1,<6.0.0'], 'zxcvbn': ['zxcvbn>=4.4.28,<5.0.0']}

entry_points = \
{'console_scripts': ['dialogus = interrogatio.main:main_dialogus',
                     'interrogatio = interrogatio.main:main_interrogatio']}

setup_kwargs = {
    'name': 'interrogatio',
    'version': '1.0.3',
    'description': 'Prompting library for terminals',
    'long_description': 'interrogatio\n============\n\nA python library to prompt user for inputs in a terminal application.\n\n\nWhat is interrogatio\n********************\n\ninterrogatio is a python 2/3 library based on the `python-prompt-toolkit\n<https://github.com/prompt-toolkit/python-prompt-toolkit>`_ and inspired by `PyInquirer\n<https://github.com/CITGuru/PyInquirer/>`_ that help CLI developers to ask users for inputs.\n\n\nQuestions can be rendered onto the terminal prompt or as curses dialogs.\n\n\nDocumentation\n*************\n\nInterrogatio is still under heavy development.\n\n\nGetting started\n***************\n\nRequirements\n------------\n\ninterrogatio depends on the python-prompt-toolkit library and its dependencies.\n\nInstallation\n------------\n\nUsing pip\n^^^^^^^^^\n\n::\n\n    $ pip install interrogatio\n\n\nContributing\n------------\n\nIf you want to contribute to the project, you can submit bugs, feature requests, translations or fork the github repository and submit your pull request.\n\n::\n\n    $ pip install -e \'.[test]\'\n    $ python setup.py test\n\n\nLicense\n-------\ninterrogatio is released under the `BSD 3-Clause "New" or "Revised" License <https://opensource.org/licenses/BSD-3-Clause>`_.\n',
    'author': 'Francesco Faraone',
    'author_email': None,
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/ffaraone/interrogatio',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
